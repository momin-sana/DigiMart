package com.student.digimart;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Objects;

public class SignupFragment extends Fragment {
    private TextView haveAcc;
    private Button signupBtn;
    private TextInputEditText createUsername, email, createPassword, confirmPassword, phoneNo;
    private TextInputLayout emailTextInputLayout, usernameTextInputLayout, passwordTextInputLayout, confirmPasswordTextInputLayout, phoneNoInputLayout;

    public SignupFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_signup, container, false);

        haveAcc = view.findViewById(R.id.have_acc_tv);
        haveAcc.setOnClickListener(v -> showSignIn());

//        createUsername = view.findViewById(R.id.create_Username_input_signup);
//        email = view.findViewById(R.id.create_email_input_signup);
//        createPassword = view.findViewById(R.id.create_password_input_signup);
//        confirmPassword = view.findViewById(R.id.confirm_password_input_signup);
//        phoneNo = view.findViewById(R.id.enter_phone_no_input_signup);
//
//        emailTextInputLayout = view.findViewById(R.id.createEmailTextInputLayout);
//        usernameTextInputLayout = view.findViewById(R.id.createUsernameTextInputLayout);
//        passwordTextInputLayout = view.findViewById(R.id.createPasswordTextInputLayout);
//        confirmPasswordTextInputLayout = view.findViewById(R.id.confirmPasswordTextInputLayout);
//        phoneNoInputLayout = view.findViewById(R.id.enterPhoneNoInputLayout);

        signupBtn = view.findViewById(R.id.signup_btn);
        signupBtn.setOnClickListener(v -> {
            String emailInput = Objects.requireNonNull(email.getText()).toString().trim();
            Log.d("emailinput", "onCreateView: " + emailInput);
            if (Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()){
                Toast.makeText(getActivity(), "email valid", Toast.LENGTH_SHORT).show();
                Log.d("if emailinput", "onCreateView: " + emailInput);
            }else{
                Toast.makeText(getActivity(), "email NOT valid", Toast.LENGTH_SHORT).show();

            }

        });

        return view;
    }

    private void showSignIn(){
        SigninFragment newFragment = new SigninFragment();
        FragmentTransaction transaction = getActivity().getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, newFragment);
        transaction.addToBackStack(null);
        transaction.commit();

    }

    private void validateFields() {
        String emailInput = Objects.requireNonNull(email.getText()).toString().trim();
        String usernameInput = Objects.requireNonNull(createUsername.getText()).toString().trim();
        String passwordInput = Objects.requireNonNull(createPassword.getText()).toString().trim();
        String confirmInput = Objects.requireNonNull(confirmPassword.getText()).toString().trim();
        String phoneNoInput = Objects.requireNonNull(phoneNo.getText()).toString().trim();



        if (!TextUtils.isEmpty(usernameInput) && !TextUtils.isEmpty(emailInput) &&!TextUtils.isEmpty(passwordInput) &&!TextUtils.isEmpty(confirmInput) &&!TextUtils.isEmpty(phoneNoInput)){
            if (Patterns.EMAIL_ADDRESS.matcher(emailInput).matches()){
                if (isValidUsername(usernameInput)){
                    if (isValidPassword(passwordInput)){
                        if (confirmInput.equals(passwordInput)){
                            if (isValidPhoneNumber(phoneNoInput)){
                                Toast.makeText(this.getActivity(), "successfully login", Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            confirmPasswordTextInputLayout.setError(getString(R.string.error_msg_invalid_password_matching));
                        }
                    }
                }
            }else{
                emailTextInputLayout.setHelperText(getString(R.string.error_msg_invalid_username));
            }
        }


    }



    private boolean isValidUsername(String username) {
        String usernameREX ="^"+"(?=\\S+$)"+".{8,15}"+"$";
        if (!username.matches(usernameREX)) {
            usernameTextInputLayout.setHelperText(getString(R.string.error_msg_invalid_username));
            usernameTextInputLayout.setError(getString(R.string.error_msg_invalid_username));
            Log.d("checking validation", "onClick: " + R.string.error_msg_invalid_username);

            return false;
        } else {
            usernameTextInputLayout.setError(null);
            return true;
        }

    }

    private boolean isValidPassword(String password) {
        String passwordREX ="^(?=.*[a-zA-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        if (!password.matches(passwordREX)) {
            passwordTextInputLayout.setError(getString(R.string.error_msg_invalid_password_created));
            return false;
        } else {
            passwordTextInputLayout.setError(null);
            return true;
        }
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        String phoneNoREX ="^\\+92[1-9][0-9]{9}$";
        if (!phoneNumber.matches(phoneNoREX)) {
            phoneNoInputLayout.setError(getString(R.string.error_msg_invalid_phoneNo));
            return false;
        } else {
            phoneNoInputLayout.setError(null);
            return true;
        }
    }

}